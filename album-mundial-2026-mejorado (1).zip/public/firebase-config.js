// ============================================================================
// Configuración de Firebase — sincronización entre dispositivos
// ============================================================================
// Pegá acá los datos de TU proyecto de Firebase (es gratis). Paso a paso en
// el README, sección "Sincronizar entre dispositivos".
//
// Un apiKey de Firebase para web NO es secreto — está pensado para viajar
// dentro del código del sitio. La seguridad real la dan las reglas de
// Firestore (mirá el README), no ocultar esta clave.
//
// Mientras dejes los valores de ejemplo tal cual están, la app funciona
// igual que siempre pero con la sincronización desactivada.
// ============================================================================

export const firebaseConfig = {
  apiKey: "PEGA_ACA_TU_API_KEY",
  authDomain: "PEGA_ACA_TU_PROYECTO.firebaseapp.com",
  projectId: "PEGA_ACA_TU_PROYECTO",
  storageBucket: "PEGA_ACA_TU_PROYECTO.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:0000000000000000000000",
};
